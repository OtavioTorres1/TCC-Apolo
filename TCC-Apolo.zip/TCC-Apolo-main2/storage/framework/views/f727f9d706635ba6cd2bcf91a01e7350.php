<!DOCTYPE html>
<html>
<head>
    <title>Novo contato</title>
</head>
<body>
    <h2>Dados do contato</h2>
    
    <p><strong>Nome:</strong> <?php echo e($dados['nome']); ?> <?php echo e($dados['sobrenome']); ?></p>
    <p><strong>E-mail:</strong> <?php echo e($dados['email']); ?></p>
    <p><strong>Telefone:</strong> <?php echo e($dados['telefone'] ?? 'Não informado'); ?></p>
    <p><strong>Mensagem:</strong></p>
    <p><?php echo e($dados['assunto']); ?></p>
</body>
</html><?php /**PATH C:\TCC-Apolo-main\resources\views/emails/contato.blade.php ENDPATH**/ ?>